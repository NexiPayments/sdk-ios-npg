import Foundation
import UIKit
import WebKit

extension String: Error {}

public class PaymentClient{
    
    private final var host: String?
    private final var xApiKey: String?
    
    public init(host: String?, xApiKey: String?) throws {
        
        if(UUID(uuidString: xApiKey!) == nil) {
            throw NotValidXApiKeyException.init(error: "Not valid x-Api-Key format")}
        
        self.host = host
        self.xApiKey = xApiKey
    }
    
    /**
     Call /api/phoenix-0.0/psp/api/v1/orders/card_verification
     Refer to https://dev-xpta.iplusservice.it/it/api/post-orders-card_verification
     */
    public func CardVerification (param: CardVerificationRequest ) async throws -> CardVerificationResponse?
    {
        let httpResponse = try await CardVerificationHandler.Handle(cardVerificationRequest: param, hostname: host!, xApiKey: xApiKey!)
        return httpResponse
    }
    
    /**
     Call /api/phoenix-0.0/psp/api/v1/payment_methods
     */
    public func GetPaymentMethods () async throws -> PaymentMethodsResponse?
    {
        let paymentResponse = try await PaymentMethodsHandler.Handle(hostname: host!, xApiKey: xApiKey!)
        return paymentResponse
    }
    
    /**
     Call /api/phoenix-0.0/psp/api/v1/orders/hpp
     */
    public func CreateOrderHPP (param: CreateHostedFieldOrderRequest) async throws -> CreateHostedOrderResponse
    {
        let httpResponse = try await CreateHostedOrderHandler.Handle(body: param, hostname: host!, xApiKey: xApiKey!)
        return httpResponse
    }
    
    /**
     Call /api/phoenix-0.0/psp/api/v1/orders/hpp and open a web view in order to proceed to the payment
     */
    public func CreateOrderHPPWebView(param: CreateHostedFieldOrderRequestWebView, cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws {
        
        // Set resulturl and cancelurl to hardcoded string in order to intercep the order result from the webview and return the result
        // to the host app
        let paymentSession = PaymentSession(actionType: param.paymentSession?.actionType, amount: param.paymentSession?.amount, recurrence: param.paymentSession?.recurrence, captureType: param.paymentSession?.captureType, exemptions: param.paymentSession?.exemptions, language: param.paymentSession?.language, resultUrl: "https://result.dev", cancelUrl: "https://cancel.dev", notificationUrl: param.paymentSession?.notificationUrl)
        let req =  CreateHostedFieldOrderRequest(order: param.order, paymentSession: paymentSession)
        let httpResponse = try await CreateOrderHPP(param: req)
        
        let customViewController = await WebViewViewController(url: httpResponse.hostedPage!,cbResultOk: { ()->Void in
            do{
                let order = try await GetOrderByIdHandler.Handle(orderId: param.order!.orderId!, hostname: self.host!, xApiKey: self.xApiKey!)
                try await cbResultOk(order!.operations!.last!)
            }
        },cbResultCancel: { ()->Void in
            do{
                try await cbResultCancel("User cancel the payment")
            }
        }
        )
        await controller.present(customViewController, animated: true, completion:nil)
    }
    
    public func submit2StepsThreeDsRequest(param: ThreeDSInitRequest, card: Card,cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws
    {
        var dsRequest = param
        dsRequest.card = card
        let httpResponse = try await TwoStepsInit.Handle(body: dsRequest, hostname:  self.host!, xApiKey: self.xApiKey!)
        
        let htmlResponse = try await PostFormHandlerData().postWithFormRequest(threeDSAuthUrl: httpResponse.threeDSAuthUrl!, returnUrl: "https://result.dev", operationId: (httpResponse.operation?.operationId)!, dsRequest: httpResponse.threeDSAuthRequest!)
        
        let authUrlViewController = await ThreeDSAuthUrlViewController(htmlString: htmlResponse, cbResultOk: { ()->Void in
            do{
                let paymentReq = ThreeDSPaymentRequest.init(operationId: httpResponse.operation?.operationId, order: dsRequest.order, card: card, recurrence: dsRequest.recurrence, exemptions: dsRequest.exemptions, threeDSAuthData: ThreeDSAuthData.init(threeDSAuthResponse: httpResponse.threeDSAuthRequest!))
                let httpResponse = try await TwoStepsPaymentHandler.Handle(body: paymentReq, hostname:  self.host!, xApiKey: self.xApiKey!)
                let order = try await GetOrderByIdHandler.Handle(orderId: param.order!.orderId!, hostname: self.host!, xApiKey: self.xApiKey!)
                try await cbResultOk(order!.operations!.last!)
            }
            catch let err{
                try await cbResultCancel(err)
            }
        },cbResultCancel: { ()->Void in
            do{
                try await cbResultCancel("User cancel the payment")
            }
        })
        
        await controller.present(authUrlViewController, animated: true, completion:nil)
    }
    
    public func submit3StepsThreeDsRequest(param: ThreeDSInitRequest, card: Card,cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws
    {
        var dsRequest = param
        dsRequest.card = card
        let httpResponse = try await ThreeStepsInit.Handle(body: dsRequest, hostname:  self.host!, xApiKey: self.xApiKey!)
        
        let htmlResponse = try await PostFormHandlerData().postWithFormRequest(threeDSAuthUrl: httpResponse.threeDSAuthUrl!, returnUrl: "https://result.dev", operationId: (httpResponse.operation?.operationId)!, dsRequest: httpResponse.threeDSAuthRequest!)
        
        let authUrlViewController = await ThreeDSAuthUrlViewController(htmlString: htmlResponse, cbResultOk: { ()->Void in
            do{
                let validationReq = ThreeDSValidationRequest.init(operationId: httpResponse.operation?.operationId, threeDSAuthResponse: httpResponse.threeDSAuthRequest!)
                let httpValidationResponse = try await ThreeStepsPaymentValidation.Handle(body: validationReq, hostname:  self.host!, xApiKey: self.xApiKey!)
                
                let paymentReq = ThreeDSPaymentRequest.init(operationId: httpResponse.operation?.operationId, order: dsRequest.order, card: card, recurrence: dsRequest.recurrence, exemptions: dsRequest.exemptions, threeDSAuthData: ThreeDSAuthData.init(threeDSAuthResponse: httpResponse.threeDSAuthRequest!, authenticationValue: httpValidationResponse.threeDSAuthResult?.authenticationValue, eci: httpValidationResponse.threeDSAuthResult?.eci, xid: httpValidationResponse.threeDSAuthResult?.xid))
                let httpPaymentResponse = try await ThreeStepsPaymentHandler.Handle(body: paymentReq, hostname:  self.host!, xApiKey: self.xApiKey!)
                let order = try await GetOrderByIdHandler.Handle(orderId: param.order!.orderId!, hostname: self.host!, xApiKey: self.xApiKey!)
                try await cbResultOk(order!.operations!.last!)
            }
            catch let err {
                try await cbResultCancel(err)
            }
        },cbResultCancel: { ()->Void in
            do{
                try await cbResultCancel("User cancel the payment")
            }
        })
        
        await controller.present(authUrlViewController, animated: true, completion:nil)
    }
    
    public func TwoStepsOrders(param: ThreeDSInitRequest, card: Card, cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws {
        try await self.submit2StepsThreeDsRequest(param: param, card: card, cbResultOk: cbResultOk, cbResultCancel: cbResultCancel, controller: controller)
    }
    
    public func ThreeStepsOrders(param: ThreeDSInitRequest, card: Card, cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws {
        try await self.submit3StepsThreeDsRequest(param: param, card: card, cbResultOk: cbResultOk, cbResultCancel: cbResultCancel, controller: controller)
    }
    
    public func OpenCardForm(controller: UIViewController, cbOnSubmit: @escaping(() async throws -> Void)) async throws {
        let storyboard =  await UIStoryboard.init(name: "Form", bundle: Bundle(for: FormViewController.self))
        let formViewController = await storyboard.instantiateViewController(withIdentifier:"FormViewController") as!FormViewController
        await formViewController.setDsRequest(cbOnSubmit: { (card: CardData)->Void in
            do{
               try await cbOnSubmit()
            }
        })
    
        await controller.present(formViewController, animated: true, completion: nil)
    }
    
    public func moto (param: MOTORequest) async throws -> MOTOResponse
    {
        let httpResponse = try await MotoHandler.Handle(body: param, hostname: host!, xApiKey: xApiKey!)
        return httpResponse
    }
}




