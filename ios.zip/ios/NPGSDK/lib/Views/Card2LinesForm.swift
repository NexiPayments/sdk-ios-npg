import UIKit
@IBDesignable
public class Card1LineForm: UIView {
    let nibName = "Card1LineForm"
    var contentView:UIView?
    var isExpireDateEntered = true
    
    @IBOutlet weak var pan: UITextField!
    @IBOutlet weak var cvv: UITextField!
    @IBOutlet weak var date: UITextField!
    

    public func twoStepsOrder(sdk: PaymentClient, param: ThreeDSInitRequest, cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws {
        let p = pan.text!
        let card = Card.init(pan:pan.text!.replacingOccurrences(of: " ", with: "", options: NSString.CompareOptions.literal, range: nil), expiryDate: date.text!.replacingOccurrences(of: "/", with: "", options: NSString.CompareOptions.literal, range: nil), cvv: cvv.text!)
        try await sdk.TwoStepsOrders(param: param, card: card, cbResultOk: cbResultOk, cbResultCancel: cbResultCancel, controller: controller)
    }
    
    public func threeStepsOrder(sdk: PaymentClient, param: ThreeDSInitRequest, cbResultOk: @escaping((Operation) async throws -> Void), cbResultCancel: @escaping((Error) async throws -> Void), controller: UIViewController) async throws {
        let p = pan.text!
        let card = Card.init(pan:pan.text!.replacingOccurrences(of: " ", with: "", options: NSString.CompareOptions.literal, range: nil), expiryDate: date.text!.replacingOccurrences(of: "/", with: "", options: NSString.CompareOptions.literal, range: nil), cvv: cvv.text!)
        try await sdk.ThreeStepsOrders(param: param, card: card, cbResultOk: cbResultOk, cbResultCancel: cbResultCancel, controller: controller)
    }
    
    @IBAction func panOnChange(_ sender: Any) {
      
        pan.setupLeftSideImage(ImageViewNamed: CardHelper.decodeBrand(number: pan.text!).rawValue)
        pan.text = CardHelper.formatCreditCardString(creditCardString: pan.text!)
    }

    @IBAction func panChanged(_ sender: Any) {
        
        var errors = Validator.validate(text: pan.text!, with: [.notEmpty, .validPan])
        if(errors != nil && !errors!.isEmpty){
            pan.removeCard()
            pan.setupError()
            return
        }
        pan.removeError()
        pan.setupLeftSideImage(ImageViewNamed: CardHelper.decodeBrand(number: pan.text!).rawValue)
        pan.text = CardHelper.formatCreditCardString(creditCardString: pan.text!)
    }
    
    @IBAction func dateOnChange(_ sender: Any) {
        if (date.text!.count == 1) {
            isExpireDateEntered = true
        }
        if(date.text!.count == 2 && !date.text!.contains("/") && isExpireDateEntered){
            date.text = date.text! + "/"
            isExpireDateEntered = false
        }
    }
    
    @IBAction func dateChanged(_ sender: Any) {
        let ds = date.text
        
        var errors = Validator.validate(text: date.text!, with: [.notEmpty, .validDate])
        if(errors != nil && !errors!.isEmpty){
            date.setupError()
            return
        }
        
        date.removeError()
        var dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "MMyy"
        var d = dateFormatterGet.date(from: ds!)
        if(d == nil){
            dateFormatterGet = DateFormatter()
            dateFormatterGet.dateFormat = "MM/yy"
            d = dateFormatterGet.date(from: ds!)
        }
        
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "MM/yy"
        date.text = dateFormatterPrint.string(from: d!)
       
    }
    
    @IBAction func cvvChanged(_ sender: Any) {
        let cv = cvv.text
        
        var errors = Validator.validate(text: cvv.text!, with: [.notEmpty, .validCvv])
        if(errors != nil && !errors!.isEmpty){
            cvv.setupError()
            return
        }
        
        cvv.removeError()
    }
        
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    public func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        contentView = view
    }
    func loadViewFromNib() -> UIView? {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: nibName, bundle: bundle)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
}
