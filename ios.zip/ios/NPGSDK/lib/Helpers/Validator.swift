import Foundation



class Validator {
    static func validate(text: String, with rules: [Rule]) -> String? {
        return rules.compactMap({ $0.check(text) }).first
    }

}

struct Rule {
    
    /// AMEX
    ///
    static let CARD_CVC_LENGTH_AMEX = 4
    static let CARD_NUMBER_AMEX_LENGTH = 15
    ///
    /// OTHER CARDS
    ///
    static let CARD_NUMBER_MIN_LENGTH = 14
    static let CARD_CVC_LENGTH = 3
    static let CARD_NUMBER_LENGTH = 16
    static let CARD_NUMBER_DINERS_LENGTH = 14
    
    // Return nil if matches, error message otherwise
    let check: (String) -> String?

    static let notEmpty = Rule(check: {
        return $0.isEmpty ? "Mandatory Field" : nil
    })
    
    static let validPan = Rule(check: {
        if $0.count >= CARD_NUMBER_MIN_LENGTH{
            if $0.count == 0 || !CardHelper.checkLuhm($0)  {
                return "Not a valid card number"
            }
            return nil
        }
        return "Not a valid card number"
    })
    
    static let validDate = Rule(check: {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "MMyy"
        let date1 =  dateFormatterGet.date(from: $0)
        
        let dateFormatterGet2 = DateFormatter()
        dateFormatterGet2.dateFormat = "MM/yy"
        let date2 =  dateFormatterGet2.date(from: $0)
        if(date1 == nil && date2 == nil){
            return "Not a valid Date"
        }
        
        return nil
    })
    
    
    static let validCvv = Rule(check: {
        CardHelper.checkLength(text: $0, maxLength: CARD_CVC_LENGTH_AMEX) ? nil : "Not a valid CVV"
    })

}
