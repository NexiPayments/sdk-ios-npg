import Foundation

class CardHelper {
    
    ///
    /// AMEX
    ///
    static let CARD_CVC_LENGTH_AMEX = 4
    static let CARD_NUMBER_AMEX_LENGTH = 15
    ///
    /// OTHER CARDS
    ///
    static let CARD_NUMBER_MIN_LENGTH = 14
    static let CARD_CVC_LENGTH = 3
    static let CARD_NUMBER_LENGTH = 16
    static let CARD_NUMBER_DINERS_LENGTH = 14
    
//    static func validate(cardNumber: String?) -> String? {
//        if cardNumber!.count >= CARD_NUMBER_MIN_LENGTH{
//            if cardNumber!.count == 0 || !checkLuhm(cardNumber!)  {
//                return "Invalid card number"
//            }
//            return nil
//        }
//        return "Invalid card number"
//    }
    
    // Validate card number with Luhm algorithm
    static public func checkLuhm(_ number: String) -> Bool {
        let cardNumber = number.replacingOccurrences(of: " ", with: "")
        let cclength = cardNumber.count;
        let characters = Array(cardNumber)
        let parity = cclength % 2;
        var sum = 0;
        for i in 0..<cclength {
            var ccdigit = Int(String(characters[i]));
            if (i % 2 == parity) {
                ccdigit = ccdigit! * 2;
            }
            if (ccdigit! > 9) {
                ccdigit = ccdigit! - 9;
            }
            sum = sum + ccdigit!;
        }
        return (sum % 10 == 0);
    }
    
    
    
    
    static func check(expire: String?) -> String? {

        let expireFixed = NSMutableString(string: expire!)
        // If month was inserted
        if (expireFixed.length > 0 && (expireFixed.length % 4) == 0) {
            let c = Array(expireFixed as String)[expire!.count - 1]
            // Check if last character is number
            if "0"..."9" ~= c {
                // Then append the backslash
                expireFixed.insert("/", at: 2)
            }
        }

        return(checkDate(expire: expireFixed as String))
    }

    static func checkDate(expire: String) -> String? {
        let expires = expire.split(separator: "/")
        if expires.count > 1 {
            guard let month = Int(expires[0]) else {
                return "Invalid month"
            }
            if month > 13 || month <= 0 {
                return "Invalid month"
            }
            // If split was successful, update card expire date
            if expires.count > 1{
                guard let year = Int(expires[1]) else {
                    return "Invalid year"
                }
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy/MM/dd HH:mm"
                let expireDate = formatter.date(from: "20\(year)/\(month)/01 00:00")
                let currentDate = Date()
                if expireDate == nil || expireDate! <= currentDate {
                    return "Invalid year"
                }
            }
            return nil
        }
        return "Invalid expire date"
    }
//
//    static func checkCvv(cvv: String, cardNumber: String) -> String? {
//        let cardNumber = cardNumber.replacingOccurrences(of: " ", with: "", options: NSString.CompareOptions.literal, range: nil)
//        if (cardNumber.count == CARD_NUMBER_AMEX_LENGTH && cvv.count > 3) {
//            return checkLength(text: cvv, maxLength: CARD_CVC_LENGTH_AMEX)
//
//        } else if ((cardNumber.count == CARD_NUMBER_LENGTH || cardNumber.count == CARD_NUMBER_DINERS_LENGTH) && cvv.count > 2){
//            return checkLength(text: cvv, maxLength: CARD_CVC_LENGTH)
//        }
//        return "Invalid cvv"
//    }
    
    
    
    static public func checkLength(text: String, maxLength: Int) -> Bool {
        if text.count > maxLength {
            return false
        } else {
            return true
        }
    }
    
     static func formatCreditCardString(creditCardString : String) -> String {
         let trimmedString = creditCardString.components(separatedBy: .whitespaces).joined()

         let arrOfCharacters = Array(trimmedString)
         var modifiedCreditCardString = ""

         if(arrOfCharacters.count > 0) {
             for i in 0...arrOfCharacters.count-1 {
                 modifiedCreditCardString.append(arrOfCharacters[i])
                 if((i+1) % 4 == 0 && i+1 != arrOfCharacters.count){
                     modifiedCreditCardString.append(" ")
                 }
             }
         }
         return modifiedCreditCardString
     }
    
    
    static func decodeBrand(number: String) -> CardBrand {
        let limitMin = "222100"
        let limitMax = "272099"
        
        let validCards = "(23|24|25|26|4|5|6|37|34|35|36|38|304|305)[0-9]*"
        let regexDiners = "(36|38|304|305)[0-9]*"
        let regexMaestro = "^(50|56|57|58)[0-9]*"
        let regexAmex = "^(37|34)[0-9]*"
        let regexJcb = "^(35)[0-9]*"
        
        if !checkRegex(number, expr: validCards) && !(number == "") {
            if(number == "30" || number == "3"){
                return .NO_BRAND
            }
            let i = number.replacingOccurrences(of: "", with: "")
            if !(number == "") && i.count <= 6 && Array(number)[0] == "2" {
                let matchMin = Int(limitMin.prefix(i.count))
                let matchMax = Int(limitMax.prefix(i.count))
                
                let inf = Int(i)! < matchMin!
                let sup = Int(i)! > matchMax!
                
                if inf || sup {
                    return .NO_BRAND
                }
                else{
                    return .NO_BRAND
                }
            } else if number.count > 5 {
                if checkMastercard(number) {
                    return .MASTERCARD
                }
            }
            return .NO_BRAND
        }
        
        
        if number == "" {
            return .NO_BRAND
        }
        
        if Array(number)[0] == "4" {
            return .VISA
        }
        if Array(number)[0] == "6" {
            return .MAESTRO
        }
        
        if number.count > 0 {
            if Array(number)[0] == "5" {
                if checkRegex(number, expr: regexMaestro) {
                    return .MAESTRO
                }
                return .MASTERCARD
            }
            else if checkRegex(number, expr: regexDiners) {
                return .DINERS
            }
            else if checkRegex(number, expr: regexAmex) {
                return .AMEX
            }
            else if checkRegex(number, expr: regexJcb) {
                return .JCB
            }
        }
        if number.count > 5 {
            if checkMastercard(number) {
                return .MASTERCARD
            }
        }
        
        return .NO_BRAND
    }
    
    private  static func checkMastercard(_ number: String) -> Bool {
        let sub = Int(number.prefix(6).replacingOccurrences(of: " ", with: ""))!
        if sub >= 222100 && sub <= 272099 {
            return true
        } else {
            return false
        }
    }
    
    private  static func checkRegex(_ str: String, expr: String) -> Bool {
        let regex = try! NSRegularExpression(pattern: expr, options: .caseInsensitive)
        return regex.firstMatch(in: str, options: [], range: NSMakeRange(0, str.utf16.count)) != nil
    }
}



