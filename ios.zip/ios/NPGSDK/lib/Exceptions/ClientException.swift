import Foundation


public struct ClientException: Error {

    public var errors: ClientError?
    public init(errors: ClientError? = nil) {
        self.errors = errors
    }

}

