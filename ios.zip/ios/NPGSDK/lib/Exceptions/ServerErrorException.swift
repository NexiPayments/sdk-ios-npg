import Foundation

public struct ServerErrorException: Error {
    
    public var errors: ServerError?
    public init(errors: ServerError? = nil) {
        self.errors = errors
    }
    
}
