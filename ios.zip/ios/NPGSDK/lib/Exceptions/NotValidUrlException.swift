import Foundation

public struct NotValidUrlException: Error {
    
    public var error: String
    public init(error: String) {
        self.error = error
    }
 
    
}
