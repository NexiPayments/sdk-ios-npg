import Foundation


public struct UnauthorizedException: Error {
    
    public var errors: UnauthorizedErrors?
    public init(errors: UnauthorizedErrors? = nil) {
        self.errors = errors
    }
    
}
