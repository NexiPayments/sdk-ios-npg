//
//  ClientErrorException.swift
//  NPGSDK
//
//  Created by Oncode on 21/11/22.
//

import Foundation

public struct ServerErrorException: Error {
    
    public var errors: ServerError?
    public init(errors: ServerError? = nil) {
        self.errors = errors
    }
    
}
