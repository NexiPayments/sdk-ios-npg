import Foundation

class HandlerUrlBuilder {

    public static func buildHttps(hostname:String , endpoint:String) -> String {
        return "https://" + hostname + endpoint;
    }

}
