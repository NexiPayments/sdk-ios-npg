import Foundation

class TwoStepsPaymentHandler{
    
    public static func Handle(body: ThreeDSPaymentRequest,hostname:String, xApiKey: String) async throws -> ThreeDSPaymentResponse {
        let endpoint = "/api/phoenix-0.0/psp/api/v1/orders/2steps/payment"
        let url = HandlerUrlBuilder.buildHttps(hostname: hostname, endpoint: endpoint)
        let httpService = HttpService.init(url: url, xApiKey: xApiKey)
        
        let httpResponse = try await httpService.post(param: body, responseClass: ThreeDSPaymentResponse()) as? ThreeDSPaymentResponse
        return httpResponse!
        
    }
}
