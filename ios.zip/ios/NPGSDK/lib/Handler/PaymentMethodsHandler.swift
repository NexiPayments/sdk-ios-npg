import Foundation

class PaymentMethodsHandler{
    public static func Handle(hostname:String, xApiKey: String) async throws -> PaymentMethodsResponse{
        let endpoint = "/api/phoenix-0.0/psp/api/v1/payment_methods"
        let url = HandlerUrlBuilder.buildHttps(hostname: hostname, endpoint: endpoint)
        let httpService = HttpService.init(url: url, xApiKey: xApiKey)
        let httpResponse = try await httpService.get(of: PaymentMethodsResponse.self) as PaymentMethodsResponse
        return httpResponse

       }

}
