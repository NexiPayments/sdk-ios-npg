import Foundation

class ThreeStepsInit{
    
    public static func Handle(body: ThreeDSInitRequest,hostname:String, xApiKey: String) async throws -> ThreeDSInitResponse{
        
        let endpoint = "/api/phoenix-0.0/psp/api/v1/orders/3steps/init"
        let url = HandlerUrlBuilder.buildHttps(hostname: hostname, endpoint: endpoint)
        let httpService = HttpService.init(url: url, xApiKey: xApiKey)
        
        let httpResponse = try await httpService.post(param: body, responseClass: ThreeDSInitResponse()) as? ThreeDSInitResponse
        return httpResponse!

       }
    
}
