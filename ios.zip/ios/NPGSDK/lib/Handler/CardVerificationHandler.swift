import Foundation

class CardVerificationHandler{
    public static func Handle(cardVerificationRequest: CardVerificationRequest,hostname:String, xApiKey: String) async throws -> CardVerificationResponse{
        let endpoint = "/api/phoenix-0.0/psp/api/v1/orders/card_verification"
        let url = HandlerUrlBuilder.buildHttps(hostname: hostname, endpoint: endpoint)
        let httpService = HttpService.init(url: url, xApiKey: xApiKey)
        let httpResponse = try await httpService.post(param: cardVerificationRequest, responseClass: CardVerificationResponse()) as? CardVerificationResponse
        return httpResponse!
        
    }
}
