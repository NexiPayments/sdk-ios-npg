import Foundation

class CreateHostedOrderHandler{
    public static func Handle(body: CreateHostedFieldOrderRequest,hostname:String, xApiKey: String) async throws -> CreateHostedOrderResponse{
        let endpoint = "/api/phoenix-0.0/psp/api/v1/orders/hpp"
        let url = HandlerUrlBuilder.buildHttps(hostname: hostname, endpoint: endpoint)
        let httpService = HttpService.init(url: url, xApiKey: xApiKey)
        
        let httpResponse = try await httpService.post(param: body, responseClass: CreateHostedOrderResponse()) as? CreateHostedOrderResponse
        return httpResponse!

       }

}
