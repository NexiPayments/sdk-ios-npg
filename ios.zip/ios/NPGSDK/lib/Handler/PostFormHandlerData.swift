import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

class PostFormHandlerData {
    
  
    func postWithFormRequest(threeDSAuthUrl: String, returnUrl: String, operationId: String, dsRequest: String) async throws -> String{

        let requestURL = URL(string: threeDSAuthUrl)
        var request = URLRequest(url: requestURL!)
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = "ThreeDsRequest=\(dsRequest)&ReturnUrl=\(returnUrl)&transactionId=\(operationId)".data(using: .utf8)!
        
        let (data, urlResponse) = try await URLSession.shared.data(for: request)
        let httpResponse = urlResponse as? HTTPURLResponse
        
        switch httpResponse!.statusCode {
            
        case 200:
            return (String(data: data, encoding: .utf8)!)
            
        case 400:
            print("ERROR 400")
            let errors = try JSONDecoder().decode(ClientError.self,from:data)
            throw ClientException.init(errors: errors)
            
        case 401:
            print("ERROR 401")
            let errors = try JSONDecoder().decode(UnauthorizedErrors.self, from: data)
            throw UnauthorizedException.init(errors: errors)
            
        case 500:
            print("ERROR 500")
            let errors = try JSONDecoder().decode(ServerError.self,from:data)
            throw ServerErrorException.init(errors: errors)
            
        default:
            // TODO add specific exeption
            throw URLError(URLError.Code(rawValue: httpResponse!.statusCode))
            
        }
    }
    

}
