import Foundation
import UIKit
import WebKit

public class FormViewController: UIViewController, WKUIDelegate, WKNavigationDelegate {
    
    var cbOnSubmit: ((CardData) async throws -> Void)? = nil
    
    
    func setDsRequest(cbOnSubmit: @escaping((CardData) async throws -> Void)){
        self.cbOnSubmit = cbOnSubmit
    }
}

extension UITextField {
    
    func setUnderLine() {
        let border = CALayer()
        let width = CGFloat(0.5)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width - 10, height: self.frame.size.height)
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
    
    func setupLeftSideImage(ImageViewNamed: String?) {
        let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 40, height: 40))
        
        imageView.image = UIImage(named: ImageViewNamed!, in: Bundle(for: PaymentClient.self), with: nil)
        let imageViewContainerView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 60))
        imageViewContainerView.addSubview(imageView)
        leftView = imageViewContainerView
        leftViewMode = .always
        self.tintColor = .lightGray
    }
    
    func removeCard() {
        leftView = nil
    }
    
    func setupError() {
//        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 15, height: 15))
//
//        imageView.image = UIImage(named: "error", in: Bundle(for: NPGSDK.self), with: nil)
//        let imageViewContainerView = UIView(frame: CGRect(x: 0, y: 0, width: 17, height: 15))
//        imageViewContainerView.addSubview(imageView)
//        rightView = imageViewContainerView
//        rightViewMode = .always
//        self.tintColor = .lightGray
        self.layer.borderColor = UIColor.red.cgColor
        self.layer.borderWidth = 1.0
        self.layer.cornerRadius = 5
    }
    
    func removeError() {
//        rightView = nil
        self.layer.borderColor = UIColor.systemGray5.cgColor
//        self.layer.borderWidth = nil
//        self.layer.cornerRadius = nil
    }
}



