import UIKit
import WebKit

class WebViewViewController: UIViewController, WKUIDelegate {
    private let url: String
    let cbResultOk: () async throws -> Void
    let cbResultCancel: () async throws -> Void
    
    init(url: String, cbResultOk: @escaping(() async throws -> Void), cbResultCancel: @escaping(() async throws -> Void)) {
        self.url = url
        self.cbResultOk =  cbResultOk
        self.cbResultCancel =  cbResultCancel
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("This class does not support NSCoder")
    }
    
    
    override func loadView() {
        
        let webView =  WKWebView.init()
        let url = URL(string: self.url)
        
        webView.addObserver(self, forKeyPath: "URL", options: .new, context: nil)
        webView.load(URLRequest(url:url!))
        self.view = webView
    }
    
    
    
    // Observe value
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?){
        if let key = change?[NSKeyValueChangeKey.newKey] {
            if((key as!NSURL).absoluteString!.starts(with: "https://result.dev")){
                Task{
                    try await cbResultOk()
                }
                dismiss(animated: true)
            }
            if((key as!NSURL).absoluteString!.starts(with: "https://cancel.dev")){
                Task{
                    try await cbResultCancel()
                }
                dismiss(animated:true)
            }
            
        }
    }
}
