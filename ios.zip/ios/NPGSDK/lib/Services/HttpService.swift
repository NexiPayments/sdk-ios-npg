import Foundation

class HttpService {
    var url: String
    var xApiKey: String
    
    public init(url: String?, xApiKey: String?) {
        self.url = url!
        self.xApiKey = xApiKey!
    }
    
    func post<T:Codable, S: Codable>(param: T, responseClass: S) async throws -> AnyObject {
        let body =  try JSONEncoder().encode(param)
        let requestURL = URL(string: url)
        var request = URLRequest(url: requestURL!)
        request.addValue(UUID().uuidString, forHTTPHeaderField: "Correlation-Id")
        request.addValue(xApiKey, forHTTPHeaderField: "x-api-key")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = body
        
        let (data, urlResponse) = try await URLSession.shared.data(for: request)
        let httpResponse = urlResponse as? HTTPURLResponse
        
        switch httpResponse!.statusCode {
        case 200:
            let d = String(data: data, encoding: String.Encoding.utf8)
            let res = try JSONDecoder().decode(S.self,from:data)
            return res as AnyObject
            
        case 400:
            print("ERROR 400")
            let errors = try JSONDecoder().decode(ClientError.self,from:data)
            throw ClientException.init(errors: errors)
            
        case 401:
            print("ERROR 401")
            let errors = try JSONDecoder().decode(UnauthorizedErrors.self, from: data)
            throw UnauthorizedException.init(errors: errors)
            
        case 500:
            print("ERROR 500")
            let errors = try JSONDecoder().decode(ServerError.self,from:data)
            throw ServerErrorException.init(errors: errors)
            
        default:
            // TODO add specific exeption
            throw URLError(URLError.Code(rawValue: httpResponse!.statusCode))
            
        }
    }
    
    func get<S: Decodable>(of type: S.Type) async throws -> S {
        let requestURL = URL(string: url)
        var request = URLRequest(url: requestURL!)
        request.addValue(UUID().uuidString, forHTTPHeaderField: "Correlation-Id")
        request.addValue(xApiKey, forHTTPHeaderField: "x-api-key")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let (data, urlResponse) = try await URLSession.shared.data(for: request)
        let httpResponse = urlResponse as? HTTPURLResponse
        
        switch httpResponse!.statusCode {
        case 200:
            let res2 = try JSONDecoder().decode(S.self,from:data)
            return res2 as S
            
        case 400:
            print("ERROR 400")
            let errors = try JSONDecoder().decode(ClientError.self,from:data)
            throw ClientException.init(errors: errors)
            
        case 401:
            print("ERROR 401")
            let errors = try JSONDecoder().decode(UnauthorizedErrors.self, from: data)
            throw UnauthorizedException.init(errors: errors)
            
        case 500:
            print("ERROR 500")
            let errors = try JSONDecoder().decode(ServerError.self,from:data)
            throw ServerErrorException.init(errors: errors)
            
        default:
            throw URLError(URLError.Code(rawValue: httpResponse!.statusCode))
        }
    }
}
