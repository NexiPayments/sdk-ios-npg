//
//  UnauthorizedErrors.swift
//  NPGSDK
//
//  Created by Oncode on 18/11/22.
//

import Foundation

public struct UnauthorizedErrors: Codable {
    
    public var errcode: String?
    
    public var errmsg: String?
    public init(errcode: String? = nil, errmsg: String? = nil) {
        self.errcode = errcode
        self.errmsg = errmsg
    }
    
}

