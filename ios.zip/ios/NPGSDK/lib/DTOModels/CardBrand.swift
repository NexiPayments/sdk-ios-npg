import Foundation

public enum CardBrand: String, Codable {
    case NO_BRAND = "nobrand"
    case MASTERCARD = "mastercard"
    case VISA = "visa"
    case MAESTRO = "maestro"
    case DINERS = "diners"
    case AMEX = "amex"
    case JCB = "jcb"
}
