import Foundation


public class CardData {
    
    public static var pan = ""

    /** Card expiry date in format mmyy */
    public static var expiryDate = ""

    /** Card Validation Value, when available */
    public static var cvv = ""
    public init(pan: String, expiryDate: String, cvv: String) {
        CardData.pan = pan
        CardData.expiryDate = expiryDate
        CardData.cvv = cvv
    }

}
