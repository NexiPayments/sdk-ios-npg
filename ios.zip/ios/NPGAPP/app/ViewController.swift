//
//  ViewController.swift
//  CreateOrderHppTest
//
//  Created by Oncode on 08/11/2022.
//

import UIKit
import NPGSDK
import WebKit
import UserNotifications

class ViewController: UIViewController{
    
    @IBOutlet weak var cardVerificationButton: LoadingButton!
    @IBOutlet weak var orderHppButton: LoadingButton!
    @IBOutlet weak var paymentsMethosButton: LoadingButton!
    @IBOutlet weak var orderHppWithWebViewButton: LoadingButton!
    @IBOutlet weak var steps2Button: LoadingButton!
    @IBOutlet weak var motoButton: LoadingButton!
    
    @IBOutlet weak var card2LinesForm: Card2LinesForm!
    
    let encoder = JSONEncoder()
    
    let npgsdk = try! NPGClient.shared.getInstance(host: "ngwecomm-dev.nexi.it", xApiKey: "380b409c-9100-4ecd-b6a2-36f44aa30f94")
    let npgsdkMoto = try! NPGClient.shared.getInstance(host: "ngwecomm-dev.nexi.it", xApiKey: "117d2827-2aed-45c4-8b56-f2e4e2f9942b")
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }
    
    // Create a mocked order request
    
    func cardVerification() async throws {
        let req = createMockedCardVerificationRequest()
        do{
            cardVerificationButton.loadIndicator(true)
            let responses = try await npgsdk!.CardVerification(param: req)
            cardVerificationButton.loadIndicator(false)
            showAlert(title: "Card Verification OK", body: "Card Data\n PAN:" + req.card!.pan! + "\n Exp. Date: " + req.card!.expiryDate! + "\n CVV: " + req.card!.cvv! )
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: "Card Data\n PAN:" + req.card!.pan! + "\n Exp. Date: " + req.card!.expiryDate! + "\n CVV: " + req.card!.cvv! + "\n error: " + e.errors!.errors!.first!._description!)
            cardVerificationButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: "Card Data\n PAN:" + req.card!.pan! + "\n Exp. Date: " + req.card!.expiryDate! + "\n CVV: " + req.card!.cvv! + "\n error: " + e.localizedDescription)
            cardVerificationButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: "Card Data\n PAN:" + req.card!.pan! + "\n Exp. Date: " + req.card!.expiryDate! + "\n CVV: " + req.card!.cvv! + "\n error: " + e.localizedDescription)
            cardVerificationButton.loadIndicator(false)
        }
        catch let e {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: "Card Data\n PAN:" + req.card!.pan! + "\n Exp. Date: " + req.card!.expiryDate! + "\n CVV: " + req.card!.cvv! + "\n error: " + e.localizedDescription)
            cardVerificationButton.loadIndicator(false)
        }
    }
    
    func getPaymentMethods() async throws {
                
        do{
            paymentsMethosButton.loadIndicator(true)
            let res = try await npgsdk!.GetPaymentMethods()
            print("response", res?.paymentMethods?.description)
            let paymentMethods = res?.paymentMethods?.compactMap({$0.circuit!})
            showAlert(title: "Payment Methods", body:  paymentMethods!.joined(separator: ", "))
            paymentsMethosButton.loadIndicator(false)
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Payment Methods KO", body: e.errors!.errors!.first!._description!)
            paymentsMethosButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: String(describing: e))
            paymentsMethosButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Payment Methods KO", body: String(describing: e))
            paymentsMethosButton.loadIndicator(false)
        }
        catch let e {
            showAlert(title: "Payment Methods KO", body: String(describing: e))
            paymentsMethosButton.loadIndicator(false)
        }
    }
    
    func createOrderhpp() async throws {
        
        do{
            orderHppButton.loadIndicator(true)
            let responses = try await npgsdk!.CreateOrderHPP(param: createMockedOrderRequest())
            print("response", responses.hostedPage)
            showAlert(title: "Order HPP Payment Link", body:  responses.hostedPage!)
            orderHppButton.loadIndicator(false)
            
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Order HPP KO", body: e.errors!.errors!.first!._description!)
            orderHppButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: String(describing: e))
            orderHppButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Order HPP KO", body: String(describing: e))
            orderHppButton.loadIndicator(false)
        }
        catch let e {
            showAlert(title: "Order HPP KO", body: String(describing: e))
            orderHppButton.loadIndicator(false)
        }
    }
    
    func createOrderhppWebView() async throws {
        do{
            orderHppWithWebViewButton.loadIndicator(true)
            let res = try await npgsdk!.CreateOrderHPPWebView(param:createMockedOrderRequestWebView(), cbResultOk: { (op)->Void in
                do{
                    self.showAlert(title: "Result", body: op.operationResult!.rawValue)
                }
            },cbResultCancel: { (error)->Void in
                do{
                    self.showAlert(title: "Payment Canceled", body: error.localizedDescription)
                }
            },controller:self)
            orderHppWithWebViewButton.loadIndicator(false)
            
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Order HPP Web View KO", body: e.errors!.errors!.first!._description!)
            orderHppWithWebViewButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: String(describing: e))
            orderHppWithWebViewButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Order HPP Web View KO", body: String(describing: e))
            orderHppWithWebViewButton.loadIndicator(false)
        }
        catch let e{
            showAlert(title: "Order HPP Web View KO", body: String(describing: e))
            orderHppWithWebViewButton.loadIndicator(false)
        }
    }
    
    func twoStepsOrders() async throws{
        let storyboard =   UIStoryboard.init(name: "Card2LinesView", bundle: nil)
        let formViewController =  storyboard.instantiateViewController(withIdentifier:"Card2LinesController") as!Card2LinesController
        await self.present(formViewController, animated: true, completion: nil)
    }
    
    func threeStepsOrders() async throws{
        let storyboard =   UIStoryboard.init(name: "Card1LineView", bundle: nil)
        let formViewController =  storyboard.instantiateViewController(withIdentifier:"Card1LineController") as!Card1LineController
        await self.present(formViewController, animated: true, completion: nil)
    }
    
    func moto() async throws{
        do{
            motoButton.loadIndicator(true)
            let res = try await npgsdkMoto!.moto(param:createMotoRequest())
            showAlert(title: "MOTO", body:  String(data: try encoder.encode(res), encoding: .utf8)!)
            motoButton.loadIndicator(false)
            
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "MOTO KO", body: e.errors!.errors!.first!._description!)
            motoButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "MOTO KO", body: String(describing: e))
            motoButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "MOTO KO", body: String(describing: e))
            motoButton.loadIndicator(false)
        }
        catch let e{
            showAlert(title: "MOTO KO", body: String(describing: e))
            motoButton.loadIndicator(false)
        }
    }
    
    

    
    func createMockedOrderRequest() -> CreateHostedFieldOrderRequest {
        let recurr = RecurringSettings.init(action: RecurringAction.noRecurring, contractId: "C2834987", contractType: RecurringContractType.mitScheduled, contractExpiryDate: "2023-03-16", contractFrequency: "120")
        let install = [Installment.init(date: "2023-11-13", amount: "1")]
        let transactionsummattr = TransactionSummaryAttribute.init(label: "Number of people", value: "4")
        let transactionsumm = [TransactionSummary.init(language: "eng", summaryList: [transactionsummattr] )]
        let merchant = MerchantRiskIndicator.init(deliveryEmail: "john.doe@email.com", deliveryTimeframe: "01", giftCardAmount: nil, giftCardCount: 0, preOrderDate: "2019-02-11", preOrderPurchaseIndicator: "01", reorderItemsIndicator: "01", shipIndicator: "01")
        let carholderaccinfo = CardHolderAccountInfo.init(chAccDate: "2019-02-11", chAccAgeIndicator: "01", chAccChangeDate: "2019-02-11", chAccChangeIndicator: "01", chAccPwChangeDate: "2019-02-11", chAccPwChangeIndicator: "01", nbPurchaseAccount: 0, destinationAddressUsageDate: "2019-02-11", destinationAddressUsageIndicator: "01", destinationNameIndicator: "01", txnActivityDay: 0, txnActivityYear: 0, provisionAttemptsDay: 0, suspiciousAccActivity: "01", paymentAccAgeDate: "2019-02-11", paymentAccIndicator: "0")
        
        let address = Address.init(name: "Mario Rossi", street: "Piazza Maggiore, 1", additionalInfo: "Quinto Piano, Scala B", city: "Bologna", postCode:  "40124", province: "BO", country: "ITA")
        
        let customerinfo = CustomerInfo.init(cardHolderName: "Mauro Morandi", cardHolderEmail: "mauro.morandi@nexi.it", billingAddress: address, shippingAddress: address, mobilePhoneCountryCode: "+39", mobilePhone: "3280987654", homePhone: "+391231234567", workPhone: "+391231234567", cardHolderAcctInfo: carholderaccinfo, merchantRiskIndicator: merchant)
        
        let order = Order.init(orderId: "btid12354698523651478452256", amount: "2", currency: "EUR", customerId: "mcid97295873", _description:"TV LG 3423", customField: "weekend promotion", customerInfo: customerinfo, transactionSummary: transactionsumm , installments: install, termsAndConditionsIds: ["16dd6ac6-0791-4c72-b362-85f77f1728a2"])
        
        let paymentses = PaymentSession.init(actionType: ActionType.pay, amount: "1", recurrence: recurr , captureType: CaptureType.explicit, exemptions: ExemptionsSettings.noPreference, language: "ita", resultUrl: "https://ngwecomm-dev.nexi.it/phoenix-0.0/paymentserviceapi-demo/result.jsp", cancelUrl: "https://ngwecomm-dev.nexi.it/phoenix-0.0/demo/npg-v1/cancel.jsp", notificationUrl: "https://ngwecomm-dev.nexi.it/phoenix-0.0/demo/npg-v1/notification.jsp")
        
        return CreateHostedFieldOrderRequest(order: order, paymentSession: paymentses)
    }
    
    func createMockedOrderRequestWebView() -> CreateHostedFieldOrderRequestWebView {
        let recurr = RecurringSettings.init(action: RecurringAction.noRecurring, contractId: "C2834987", contractType: RecurringContractType.mitScheduled, contractExpiryDate: "2023-03-16", contractFrequency: "120")
        let install = [Installment.init(date: "2023-11-13", amount: "1")]
        let transactionsummattr = TransactionSummaryAttribute.init(label: "Number of people", value: "4")
        let transactionsumm = [TransactionSummary.init(language: "eng", summaryList: [transactionsummattr] )]
        let merchant = MerchantRiskIndicator.init(deliveryEmail: "john.doe@email.com", deliveryTimeframe: "01", giftCardAmount: nil, giftCardCount: 0, preOrderDate: "2019-02-11", preOrderPurchaseIndicator: "01", reorderItemsIndicator: "01", shipIndicator: "01")
        let carholderaccinfo = CardHolderAccountInfo.init(chAccDate: "2019-02-11", chAccAgeIndicator: "01", chAccChangeDate: "2019-02-11", chAccChangeIndicator: "01", chAccPwChangeDate: "2019-02-11", chAccPwChangeIndicator: "01", nbPurchaseAccount: 0, destinationAddressUsageDate: "2019-02-11", destinationAddressUsageIndicator: "01", destinationNameIndicator: "01", txnActivityDay: 0, txnActivityYear: 0, provisionAttemptsDay: 0, suspiciousAccActivity: "01", paymentAccAgeDate: "2019-02-11", paymentAccIndicator: "0")
        
        let address = Address.init(name: "Mario Rossi", street: "Piazza Maggiore, 1", additionalInfo: "Quinto Piano, Scala B", city: "Bologna", postCode:  "40124", province: "BO", country: "ITA")
        
        let customerinfo = CustomerInfo.init(cardHolderName: "Mauro Morandi", cardHolderEmail: "mauro.morandi@nexi.it", billingAddress: address, shippingAddress: address, mobilePhoneCountryCode: "+39", mobilePhone: "3280987654", homePhone: "+391231234567", workPhone: "+391231234567", cardHolderAcctInfo: carholderaccinfo, merchantRiskIndicator: merchant)
        
        let order = Order.init(orderId: "btid12354698523652478452257", amount: "2", currency: "EUR", customerId: "mcid97295873", _description:"TV LG 3423", customField: "weekend promotion", customerInfo: customerinfo, transactionSummary: transactionsumm , installments: install, termsAndConditionsIds: ["16dd6ac6-0791-4c72-b362-85f77f1728a2"])
        
        let paymentses = PaymentSessionWebView.init(actionType: ActionType.pay, amount: "1", recurrence: recurr , captureType: CaptureType.explicit, exemptions: ExemptionsSettings.noPreference, language: "ita", notificationUrl: "https://ngwecomm-dev.nexi.it/phoenix-0.0/demo/npg-v1/notification.jsp")
        
        return CreateHostedFieldOrderRequestWebView(order: order, paymentSession: paymentses)
    }
    
    // Create a mocked card verification request
    func createMockedCardVerificationRequest() -> CardVerificationRequest {
        
        let install = [Installment.init(date: "2023-11-13", amount: "4")]
        let transactionsummattr = TransactionSummaryAttribute.init(label: "Number of people", value: "4")
        let transactionsumm = [TransactionSummary.init(language: "eng", summaryList: [transactionsummattr] )]
        let merchant = MerchantRiskIndicator.init(deliveryEmail: "john.doe@email.com", deliveryTimeframe: "01", giftCardAmount: nil, giftCardCount: 0, preOrderDate: "2019-02-11", preOrderPurchaseIndicator: "01", reorderItemsIndicator: "01", shipIndicator: "01")
        let carholderaccinfo = CardHolderAccountInfo.init(chAccDate: "2019-02-11", chAccAgeIndicator: "01", chAccChangeDate: "2019-02-11", chAccChangeIndicator: "01", chAccPwChangeDate: "2019-02-11", chAccPwChangeIndicator: "01", nbPurchaseAccount: 0, destinationAddressUsageDate: "2019-02-11", destinationAddressUsageIndicator: "01", destinationNameIndicator: "01", txnActivityDay: 0, txnActivityYear: 0, provisionAttemptsDay: 0, suspiciousAccActivity: "01", paymentAccAgeDate: "2019-02-11", paymentAccIndicator: "0")
        
        let address = Address.init(name: "Mario Rossi", street: "Piazza Maggiore, 1", additionalInfo: "Quinto Piano, Scala B", city: "Bologna", postCode:  "40124", province: "BO", country: "ITA")
        
        let customerinfo = CustomerInfo.init(cardHolderName: "Mauro Morandi", cardHolderEmail: "mauro.morandi@nexi.it", billingAddress: address, shippingAddress: address, mobilePhoneCountryCode: "+39", mobilePhone: "3280987654", homePhone: "+391231234567", workPhone: "+391231234567", cardHolderAcctInfo: carholderaccinfo, merchantRiskIndicator: merchant)
        
        let order = Order.init(orderId: "btid12354698523651478452154", amount: "4", currency: "EUR", customerId: "mcid97295873", _description:"TV LG 3423", customField: "weekend promotion", customerInfo: customerinfo, transactionSummary: transactionsumm , installments: install, termsAndConditionsIds: ["16dd6ac6-0791-4c72-b362-85f77f1728a2"])
        
        let card = Card.init(pan: "4349942499990906", expiryDate: "0423", cvv: "034")
        
        return CardVerificationRequest(order: order, card: card)
    }
    
    // Create a mocked card verification request
    func createMotoRequest() -> MOTORequest {
        
        let install = [Installment.init(date: "2023-11-13", amount: "4")]
        let transactionsummattr = TransactionSummaryAttribute.init(label: "Number of people", value: "4")
        let transactionsumm = [TransactionSummary.init(language: "eng", summaryList: [transactionsummattr] )]
        let merchant = MerchantRiskIndicator.init(deliveryEmail: "john.doe@email.com", deliveryTimeframe: "01", giftCardAmount: nil, giftCardCount: 0, preOrderDate: "2019-02-11", preOrderPurchaseIndicator: "01", reorderItemsIndicator: "01", shipIndicator: "01")
        let carholderaccinfo = CardHolderAccountInfo.init(chAccDate: "2019-02-11", chAccAgeIndicator: "01", chAccChangeDate: "2019-02-11", chAccChangeIndicator: "01", chAccPwChangeDate: "2019-02-11", chAccPwChangeIndicator: "01", nbPurchaseAccount: 0, destinationAddressUsageDate: "2019-02-11", destinationAddressUsageIndicator: "01", destinationNameIndicator: "01", txnActivityDay: 0, txnActivityYear: 0, provisionAttemptsDay: 0, suspiciousAccActivity: "01", paymentAccAgeDate: "2019-02-11", paymentAccIndicator: "0")
        
        let address = Address.init(name: "Mario Rossi", street: "Piazza Maggiore, 1", additionalInfo: "Quinto Piano, Scala B", city: "Bologna", postCode:  "40124", province: "BO", country: "ITA")
        
        let customerinfo = CustomerInfo.init(cardHolderName: "Mauro Morandi", cardHolderEmail: "mauro.morandi@nexi.it", billingAddress: address, shippingAddress: address, mobilePhoneCountryCode: "+39", mobilePhone: "3280987654", homePhone: "+391231234567", workPhone: "+391231234567", cardHolderAcctInfo: carholderaccinfo, merchantRiskIndicator: merchant)
        
        let order = Order.init(orderId: "btid12354698523651478452154", amount: "4", currency: "EUR", customerId: "mcid97295873", _description:"TV LG 3423", customField: "weekend promotion", customerInfo: customerinfo, transactionSummary: transactionsumm , installments: install, termsAndConditionsIds: ["16dd6ac6-0791-4c72-b362-85f77f1728a2"])
        
        let card = Card.init(pan: "49433196111148733", expiryDate: "0524", cvv: "770")
        
        return MOTORequest(order: order, card: card)
    }
    
    @IBAction func CardValidation(_ sender: UIButton) {
        Task {
            let activityIndicatorView = UIActivityIndicatorView(style: .medium)
            self.view.addSubview(activityIndicatorView)
            activityIndicatorView.startAnimating()
            try await cardVerification()
        }
    }
    
    @IBAction func ButtonUi(_ sender: UIButton) {
        Task {
            try await createOrderhpp()
        }
    }
    
    @IBAction func GetPaymentMethodButton(_ sender: UIButton) {
        Task{
            try await getPaymentMethods()
        }
    }
    
    @IBAction func CreateOrderWebView(_ sender: UIButton) {
        Task{
            try await createOrderhppWebView()
        }
    }
    
    
    @IBAction func OrderTwoSteps(_ sender: UIButton) {
        Task{
            try await twoStepsOrders()
        }
    }
    
    @IBAction func OrderThreeSteps(_ sender: UIButton) {
        Task{
            try await threeStepsOrders()
        }
    }
    
    @IBAction func Moto(_ sender: UIButton) {
        Task{
            try await moto()
        }
    }
    
//    @IBAction func CollectCardData(_ sender: UIButton) {
//        Task{
//            try await collectCardData()
//        }
//    }
    
    func showAlert(title: String, body: String){
        let alert = UIAlertController(title: title, message: body, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
}
