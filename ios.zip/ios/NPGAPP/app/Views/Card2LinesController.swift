//
//  Card2Lines.swift
//  NPGAPP
//
//  Created by Nicolo Paganin on 20/02/23.
//

import UIKit
import NPGSDK
import WebKit

class Card2LinesController: UIViewController, WKUIDelegate, WKNavigationDelegate {
    
    @IBOutlet weak var cardData: Card2LinesForm!
    
    @IBOutlet weak var twoStepsButton: LoadingButton!
    @IBOutlet weak var threeStepsButton: LoadingButton!
    
    let npgsdk = try! NPGClient.shared.getInstance(host: "ngwecomm-dev.nexi.it", xApiKey: "380b409c-9100-4ecd-b6a2-36f44aa30f94")
    
    override func viewDidLoad() {
       
        super.viewDidLoad()
    }
    
    func twoStepsOrder() async throws{
        let encoder = JSONEncoder()
        twoStepsButton.loadIndicator(true)
        do{
            try await cardData.twoStepsOrder(sdk: npgsdk!, param: createMockedThreeDSRequest(), cbResultOk: { (op)->Void in
                do{
                    self.showAlert(title: "Result", body: String(data: try encoder.encode(op), encoding: .utf8)!)
                    self.twoStepsButton.loadIndicator(false)
                }
            },cbResultCancel: { (error)->Void in
                do{
                    self.showAlert(title: "Payment Canceled", body: error.localizedDescription)
                    self.twoStepsButton.loadIndicator(false)
                }
            }, controller:self)
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Order 2 Steps KO", body: e.errors!.errors!.first!._description!)
            twoStepsButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: e.localizedDescription)
            twoStepsButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Order 2 Steps KO", body: e.localizedDescription)
            twoStepsButton.loadIndicator(false)
        }
        catch let e {
            showAlert(title: "Order 2 Steps KO", body: e.localizedDescription)
            twoStepsButton.loadIndicator(false)
        }
       
    }
    
    
    func threeStepsOrder() async throws{
        let encoder = JSONEncoder()
        threeStepsButton.loadIndicator(true)
        do{
            try await cardData.threeStepsOrder(sdk: npgsdk!, param: createMockedThreeDSRequest(), cbResultOk: { (op)->Void in
                do{
                    self.showAlert(title: "Result", body: String(data: try encoder.encode(op), encoding: .utf8)!)
                    self.threeStepsButton.loadIndicator(false)
                }
            },cbResultCancel: { (error)->Void in
                do{
                    self.showAlert(title: "Payment Canceled", body: error.localizedDescription)
                    self.threeStepsButton.loadIndicator(false)
                }
            }, controller:self)
        }
        catch let e as ClientException {
            print(String(describing: e))
            showAlert(title: "Order 3 Steps KO", body: e.errors!.errors!.first!._description!)
            threeStepsButton.loadIndicator(false)
        }
        catch let e as UnauthorizedException {
            print(String(describing: e))
            showAlert(title: "Card Verification KO", body: e.localizedDescription)
            threeStepsButton.loadIndicator(false)
        }
        catch let e as ServerErrorException {
            print(String(describing: e))
            showAlert(title: "Order 3 Steps KO", body: e.localizedDescription)
            threeStepsButton.loadIndicator(false)
        }
        catch let e {
            showAlert(title: "Order 3 Steps KO", body: e.localizedDescription)
            threeStepsButton.loadIndicator(false)
        }
       
    }
    
    @IBAction func submit2Steps(_ sender: Any) {
        Task{
            try await twoStepsOrder()
        }
    }
    
    @IBAction func submit3Steps(_ sender: Any) {
        Task{
            try await threeStepsOrder()
        }
    }
    
    func showAlert(title: String, body: String){
        let alert = UIAlertController(title: title, message: body, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    func createMockedThreeDSRequest() ->  ThreeDSInitRequest {
        let install = [Installment.init(date: "2023-11-13", amount: "1")]
        let transactionsummattr = TransactionSummaryAttribute.init(label: "Number of people", value: "4")
        let transactionsumm = [TransactionSummary.init(language: "eng", summaryList: [transactionsummattr] )]
        let merchant = MerchantRiskIndicator.init(deliveryEmail: "john.doe@email.com", deliveryTimeframe: "01", giftCardAmount: nil, giftCardCount: 0, preOrderDate: "2019-02-11", preOrderPurchaseIndicator: "01", reorderItemsIndicator: "01", shipIndicator: "01")
        let carholderaccinfo = CardHolderAccountInfo.init(chAccDate: "2019-02-11", chAccAgeIndicator: "01", chAccChangeDate: "2019-02-11", chAccChangeIndicator: "01", chAccPwChangeDate: "2019-02-11", chAccPwChangeIndicator: "01", nbPurchaseAccount: 0, destinationAddressUsageDate: "2019-02-11", destinationAddressUsageIndicator: "01", destinationNameIndicator: "01", txnActivityDay: 0, txnActivityYear: 0, provisionAttemptsDay: 0, suspiciousAccActivity: "01", paymentAccAgeDate: "2019-02-11", paymentAccIndicator: "0")
        
        let address = Address.init(name: "Mario Rossi", street: "Piazza Maggiore, 1", additionalInfo: "Quinto Piano, Scala B", city: "Bologna", postCode:  "40124", province: "BO", country: "ITA")
        
        let customerinfo = CustomerInfo.init(cardHolderName: "Mauro Morandi", cardHolderEmail: "mauro.morandi@nexi.it", billingAddress: address, shippingAddress: address, mobilePhoneCountryCode: "+39", mobilePhone: "3280987654", homePhone: "+391231234567", workPhone: "+391231234567", cardHolderAcctInfo: carholderaccinfo, merchantRiskIndicator: merchant)
        
        let order = Order.init(orderId: "btid12354698523651478452256", amount: "2", currency: "EUR", customerId: "mcid97295873", _description:"TV LG 3423", customField: "weekend promotion", customerInfo: customerinfo, transactionSummary: transactionsumm , installments: install, termsAndConditionsIds: ["16dd6ac6-0791-4c72-b362-85f77f1728a2"])
        
        let card = Card()
        
        let recurr = RecurringSettings.init(action: RecurringAction.noRecurring, contractId: "", contractType: nil, contractExpiryDate: nil, contractFrequency: nil)
        
        let exemptionSetting = ExemptionsSettings.noPreference
        
        return ThreeDSInitRequest(order:order, card: card, recurrence: recurr, exemptions: exemptionSetting)
        
    }
}
