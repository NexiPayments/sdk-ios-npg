//
//  NPGClient.swift
//  NPGAPP
//
//  Created by Oncode on 18/11/22.
//

import Foundation
import UIKit
import NPGSDK

class NPGClient{
    
    static let shared = NPGClient()
    
    private init(){}
    
//    private static var npgsdk: NPGSDK? = nil
    private static var npgsdkMap = [String : PaymentClient]()
    
    public func getInstance(host:String,xApiKey: String)throws ->PaymentClient? {
        if(NPGClient.npgsdkMap.index(forKey: xApiKey) == nil){
            do{
                NPGClient.npgsdkMap[xApiKey] = try PaymentClient(host: host,xApiKey: xApiKey)
            }
            catch let e as NotValidXApiKeyException{
                print(String(describing: e))
            }
        }
        return NPGClient.npgsdkMap[xApiKey]
        
    }
    
}









